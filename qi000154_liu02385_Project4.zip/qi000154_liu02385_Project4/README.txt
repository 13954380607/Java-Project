Group members’ names and x500s
Dongnan Liu: liu02385,  David Qi: qi000154


• Contributions of each partner (if working with a partner)
We communicate with each other
Minefield.java(together)
main.java(together)

• How to compile and run your program 
We use Intellij to compile and run our program. 
Everytime we click the green run button on the right top corner to compile and run our program. 


• Any assumptions
The game will over after all of the cells are revealed or flaged.

• Additional features that you implemented (if applicable)
 
• Any known bugs or defects in the program 


• Any outside sources (aside from course resources) consulted for ideas used in the project, in the format: 
– the logic of some methods: TA
- Google

“I certify that the information contained in this README file is complete and accurate. I have both read and followed the course policies in the ‘Academic Integrity - Course Policy’ section of the course syllabus.” 
Dongnan Liu
 David Qi